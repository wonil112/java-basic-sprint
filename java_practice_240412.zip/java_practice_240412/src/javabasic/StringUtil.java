package javabasic;

public class StringUtil {


    public static String reverse(String str) {
        String reverseString = "";
        for (int i = str.length() - 1; i >= 0; i--) {
            reverseString = reverseString + str.charAt(i);
        }
        return reverseString;
    }

    public static String concat(String str1, String str2) {
//        String concatString = "";
//        concatString = str1 + str2;
//        return concatString;
        return str1 + str2;

        public static String concat (String str1, String str2, String str3){
            return str1 + str2 + str3;

        }


    }
}
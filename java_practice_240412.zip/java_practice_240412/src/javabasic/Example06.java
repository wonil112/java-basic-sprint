package javabasic;
import java.util.Scanner;

public class Example06 {
    public static void main(String[] args) {

        // 사용자로부터 숫자 n을 입력받아, 1부터 n까지의 합을 계산하여 출력
        // 변수 선언
        int number;
        int sum = 0;
        // 사용자로부터 숫자 입력받기
        System.out.println("숫자를 입력해주세요.");
        Scanner sc = new Scanner(System.in);
        number = sc.nextInt();
        // 1부터 n까지의 숫자 반복하며 더하기
        for(int i = 1; i <= number; i++) {
            sum += i;
        }
        // 출력하기
        System.out.printf("1부터 입력하신 숫자까지의 합은 %d 입니다.", sum);
    }
}

package javabasic;

public class Example12 {
    public static void main(String[] args) {

        //person 객체를 두개 생성하고, 각 객체에 대한 정보를 출력.
        //book 객체를 생성하고, 그 객체의 정보를 출력.

        Person person1 = new Person("wonil", 30);
        Person person2 = new Person("coding", 21);
        person1.introduce();
        person2.introduce();

        Book book = new Book("자바 기초", "이정민", 5000);
        book.printTitle();
        book.printAuthor();
        book.printPrice();
    }
}

package javabasic;

import java.util.Arrays;

public class Example07 {
    public static void main(String[] args) {

        // 10개의 정수 값을 저장할 수 있는 배열을 생성하고, 1부터 10까지의 값을 배열에 저장한 후 출력.
        // 배열 생성 (길이는 10)
        int[] arr = new int[10];
        // 배열 각 자리에 1부터 10까지 순회하며 입력
        for(int i = 0; i < arr.length; i++) {
            arr[i] = i+1;
        }
        // 출력
        System.out.println(Arrays.toString(arr));
    }
}

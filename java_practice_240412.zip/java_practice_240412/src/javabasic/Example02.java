package javabasic;
import java.util.Scanner;

public class Example02 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("첫번째 숫자를 입력해주세요.");
        double num1 = sc.nextDouble();

        System.out.println("두번째 숫자를 입력해주세요.");
        double num2 = sc.nextDouble();

        double sum = num1 + num2;
        double minus = num1 - num2;
        double multiple = num1 * num2;
        double divide = num1 / num2;
        double rest = num1 % num2;

        if(num2 == 0) {
            System.out.printf("%f + %f 는 : %f 입니다. %n", num1, num2, sum);
            System.out.printf("%f - %f 는 : %f 입니다. %n", num1, num2, minus);
            System.out.printf("%f * %f 는 : %f 입니다. %n", num1, num2, multiple);
            System.out.printf("0으로 나눌 수 없습니다! %n");
            System.out.printf("%f / %f 의 나머지는 : %f 입니다. %n", num1, num2, rest);
        } else {
            System.out.printf("%f + %f 는 : %f 입니다. %n", num1, num2, sum);
            System.out.printf("%f - %f 는 : %f 입니다. %n", num1, num2, minus);
            System.out.printf("%f * %f 는 : %f 입니다. %n", num1, num2, multiple);
            System.out.printf("%f / %f 는 : %f 입니다. %n", num1, num2, divide);
            System.out.printf("%f / %f 의 나머지는 : %f 입니다. %n", num1, num2, rest);
        }
    }
}
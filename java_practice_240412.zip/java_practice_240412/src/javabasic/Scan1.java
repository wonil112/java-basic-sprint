package javabasic;
import java.util.Scanner;

public class Scan1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("이름을 입력해주세요.");
        String name = input.nextLine();

        System.out.println("나이를 입력해주세요.");
        String age = input.nextLine();

        if(!isValid(name)) {
            System.out.println("이름에 숫자는 넣지마십시오.");
            return;
        }
        if(!isValidDigit(age)) {
            System.out.println("나이에 숫자가 아닌 문자는 넣지마십시오.");
            return;
        }
        System.out.printf("귀하의 이름은 %s, 나이는 %s 세 입니다. %n", name, age);




//        if (isValid(name)) {
//           if (isValidDigit(age)) {
//                System.out.printf("귀하의 이름은 %s, 나이는 %s 세 입니다. %n", name, age);
//            } else {
//                System.out.println("잘못된 입력입니다.");
//            }
//        } else {
//            System.out.println("잘못된 입력입니다.");
//        }
    }

    public static boolean isValid(String formula) {

        String digit = "1234567890";

        for (char c : formula.toCharArray()) {
            if (digit.indexOf(c) != -1) {
                return false;
            }
        }
        return true;
    }

    public static boolean isValidDigit(String formula) {

        String str = "1234567890";

        for(char c : formula.toCharArray()) {
            if(str.indexOf(c) == -1) {
                return false;
            }
        }
        return true;
    }
    }


    /*
    String digit = "0123456789"
    for(int i = 0; i < name.length(); i++) {
     if(digit.indexOf(name.charAt(i)) != -1) {
      System.out,println("이름에 숫자가 포함되어 있습니다.");
      return;
     */
package javabasic;
import java.util.Scanner;

public class Example04 {
    public static void main(String[] args) {

        // 사용자로부터 숫자를 하나 입력받아, 이 숫자가 양수인지, 음수인지, 0인지 판단하여 출력
        // 변수 선언
        int num = 0;
        // 사용자로부터 숫자 입력받기
        System.out.println("숫자를 입력해주세요.");
        Scanner sc = new Scanner(System.in);
        num = sc.nextInt();
        // 0부터 출력
        if (num == 0) {
            System.out.println("입력하신 숫자는 0입니다.");
        }
        // 양수판단 출력
        else if (num > 0) {
            System.out.println("입력하신 숫자는 양수입니다.");
        }
        // 음수판단 출력
        else {
            System.out.println("입력하신 숫자는 음수입니다.");
        }
    }
}

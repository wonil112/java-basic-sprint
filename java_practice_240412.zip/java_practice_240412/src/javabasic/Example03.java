package javabasic;
import java.util.Scanner;

public class Example03 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int[] numberArr = new int[3];

        for (int i = 0; i < 3; i++) {
            numberArr[i] = sc.nextInt();
        }

        int maxNumber = numberArr[0];
        int minNumber = numberArr[0];

        for(int i = 1; i < numberArr.length; i++) {
            maxNumber = Math.max(maxNumber, numberArr[i]);
            minNumber = Math.min(minNumber, numberArr[i]);
        }
        System.out.println(maxNumber + "" + minNumber);
    }
}

//        System.out.println("첫번째 숫자를 입력해주세요.");
//        int num1 = sc.nextInt();
//        System.out.println("두번째 숫자를 입력해주세요.");
//        int num2 = sc.nextInt();
//        System.out.println("세번째 숫자를 입력해주세요.");
//        int num3 = sc.nextInt();
//
//        if (num1 >= num2 && num2 >= num3) {
//            System.out.printf("%d가 가장 큰 숫자이고 %d가 가장 작은 숫자입니다.", num1, num3);
//        } else if (num1 >= num3 && num3 >= num2) {
//            System.out.printf("%d가 가장 큰 숫자이고 %d가 가장 작은 숫자입니다.", num1, num2);
//        } else if (num2 >= num1 && num1 >= num3) {
//            System.out.printf("%d가 가장 큰 숫자이고 %d가 가장 작은 숫자입니다.", num2, num3);
//        } else if (num2 >= num3 && num3 >= num1) {
//            System.out.printf("%d가 가장 큰 숫자이고 %d가 가장 작은 숫자입니다.", num2, num1);
//        } else if (num3 >= num1 && num1 >= num2) {
//            System.out.printf("%d가 가장 큰 숫자이고 %d가 가장 작은 숫자입니다.", num3, num2);
//        } else {
//            System.out.printf("%d가 가장 큰 숫자이고 %d가 가장 작은 숫자입니다.", num3, num1);
//        }
//    }
//}

//        Scanner sc = new Scanner(System.in);
//        int number_1 = sc.nextInt();
//        int number_2 = sc.nextInt();
//        int number_3 = sc.nextInt();
//        int maxNumber;
//        if (number_1 > number_2) {
//            maxNumber = number_1;
//        } else {
//            maxNumber = number_2;
//        }
//        if (maxNumber < number_3) {
//            maxNumber = number_3;
//        }
//
//        int minNumber;
//        if (number_1 < number_2) {
//            minNumber = number_1;
//        } else {
//            minNumber = number_2;
//        }
//        if (minNumber > number_3) {
//            minNumber = number_3;
//    }
//
//}
//}



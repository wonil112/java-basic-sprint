package javabasic;

import java.util.Scanner;

public class Example09 {
    public static void main(String[] args) {

        // 주어진 정수 배열에서 최댓값과 최솟값을 찾아 출력
        // 배열을 입력받기
        System.out.println("원하는 숫자를 입력하세요. 숫자 사이는 공백없이 ','로 구분해주세요.");
        Scanner sc = new Scanner(System.in);
        String numberString = sc.nextLine();
        // split 으로 쪼개서 배열로 전환
        String[] numberStrings = numberString.split(",");
        // 상기 배열을 int로 전환
        int[] numbers = new int[numberStrings.length];
        for(int i = 0; i < numberStrings.length; i++) {
            numbers[i] = Integer.parseInt(numberStrings[i]);
        }
        // max 와 min 을 사용해서 최댓값 및 최솟값 찾기
//        printMaxMin(numbers);
        int maxNumber = getMax(numbers);
        int minNumber = getMin(numbers);
        System.out.printf("최대값은 %d, 최소값은 %d 입니다.", maxNumber, minNumber);
    }

//    public static void printMaxMin(int[] numbers) {
//        int maxNumber = numbers[0];
//        int minNumber = numbers[0];
//        for(int i = 0; i < numbers.length; i++) {
//            if(maxNumber < numbers[i]) {
//                maxNumber = numbers[i];
//            }
//            if(minNumber > numbers[i]) {
//                minNumber = numbers[i];
//            }
//        }
//        System.out.printf("최대값은 %d, 최소값은 %d 입니다.", maxNumber, minNumber);
//    }

    public static int getMin(int[] numbers) {
        int minNumber = numbers[0];
        for(int i = 0; i < numbers.length; i++) {
            if(minNumber > numbers[i]) {
                minNumber = numbers[i];
            }
        }
        return minNumber;
    }

    public static int getMax(int[] numbers) {
        int maxNumber = numbers[0];
        for(int i = 0; i < numbers.length; i++) {
            if(maxNumber < numbers[i]) {
                maxNumber = numbers[i];
            }
        }
        return maxNumber;
    }
}
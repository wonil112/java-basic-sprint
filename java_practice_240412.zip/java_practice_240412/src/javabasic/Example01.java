package javabasic;

public class Example01 {
    public static void main(String[] args) {
        /**
         * 다음 타입들을 가진 변수를 선언하고,
         * 각각에 적절한 값을 할당하세요:
         * int, double, char, boolean, String
         */

        int intVariable;
        Integer integerVariable = -2100000000; // null 포함가능*
        intVariable = 2100000000;
        intVariable = Integer.MAX_VALUE;
        intVariable = Integer.MIN_VALUE;
        double doubleVariable = 0.123456789012345;
        doubleVariable = Double.MAX_VALUE;

        char charVariable = 'a';
        char charVariable2 = 'A';
        boolean isTrue = false;
        String strVariable = "Spring";
        strVariable.charAt(2);
    }

}

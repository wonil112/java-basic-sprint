package javabasic;

public class Example05 {
    public static void main(String[] args) {

        // 1부터 100까지의 정수 중에서 짝수만 출력
        // 1부터 100까지의 정수 반복나열 (배열은 길이를 정하기 복잡해서 문자열로 선정)
        String sum = "";

        // 짝수만 골라내서 더하기(문자열로)

        for(int i = 1; i < 100; i++) {
            if(i % 2 == 0) {
               sum += i + ",";
            }
        }
        // 출력 (마지막 , 를 빼기 위해 상기 식에서 for문 안의 i의 범위를 < 100로 수정 후 100 추가)
        sum += 100;
        System.out.println(sum);
    }
}

package javabasic;

public class Example10 {
    public static void main(String[] args) {

        // person 클래스를 생성하고 이름(name)과 나이(age)를 필드로 가지게 하세요.
        // 해당 클래스에는 이름과 나이를 설정할 수 있는 생성자와 출력할 수 있는 매서드 포함.


        Person wonil = new Person("wonil", 33);

        System.out.println(wonil.name);
        System.out.println(wonil.age);
        wonil.introduce();

    }
}

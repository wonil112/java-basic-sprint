package javabasic;
import java.util.Scanner;

public class Example08 {
    public static void main(String[] args) {

        // 사용자로부터 5명의 학생의 점수를 입력받아 배열에 저장한 다음, 평균 점수를 계산하여 출력
        // 배열 생성(길이 5)
        int[] arr = new int[5];
        // 합계 변수 생성
        int sum = 0;
        // 5명 점수 입력받기 (입력값 하나로 수정)
        System.out.println("5명의 점수를 입력해주세요.");
        Scanner sc1 = new Scanner(System.in);
        for(int i = 0; i < arr.length; i++) {
            arr[i] = sc1.nextInt();}
//        Scanner sc2 = new Scanner(System.in);
//        arr[1] = sc1.nextInt();
//        Scanner sc3 = new Scanner(System.in);
//        arr[2] = sc1.nextInt();
//        Scanner sc4 = new Scanner(System.in);
//        arr[3] = sc1.nextInt();
//        Scanner sc5 = new Scanner(System.in);
//        arr[4] = sc1.nextInt();

        // 입력받은 점수 배열에 저장 및 합계 도출
        for (int j : arr) {  //인덱스가 중요하지 않은 경우 향상된 for loop 활용가능
            sum += j;
        }
        // 출력
        System.out.println("다섯학생의 평균점수는 : " + sum/arr.length);
    }
}
